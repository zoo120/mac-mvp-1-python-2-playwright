from datetime import date

from app import (
    PAGE_NAMES,
    get_dashboard_summary,
    query_candidates,
    query_crawled_items,
)
from database import init_database, upsert_candidate, upsert_crawled_item


def test_app_exposes_four_required_pages():
    assert PAGE_NAMES == ("今日概览", "关键词管理", "采集结果", "候选品")


def test_empty_database_summary_counts_enabled_keywords(tmp_path):
    db_path = tmp_path / "test.db"
    init_database(db_path)

    summary = get_dashboard_summary(db_path)

    assert summary == {
        "today_items": 0,
        "enabled_keywords": 30,
        "today_candidates": 0,
    }


def test_result_queries_apply_numeric_and_keyword_filters(tmp_path):
    db_path = tmp_path / "test.db"
    init_database(db_path)
    today = date.today().isoformat()
    base = {
        "title": "商用遮阳棚",
        "price": 300.0,
        "want_count": 21,
        "location": "杭州",
        "seller_type": "商家",
        "item_url": "https://www.goofish.com/item?id=100",
        "image_url": "",
        "raw_text": "商用遮阳棚 ¥300 21人想要",
        "crawl_date": today,
    }
    upsert_crawled_item({"keyword": "遮阳棚", **base}, db_path)
    upsert_crawled_item(
        {
            "keyword": "雨棚",
            **base,
            "title": "小雨棚",
            "price": 20.0,
            "item_url": "https://www.goofish.com/item?id=101",
        },
        db_path,
    )

    rows = query_crawled_items(
        db_path,
        keywords=["遮阳棚"],
        min_price=100,
        max_price=400,
        min_want_count=20,
    )

    assert [row["title"] for row in rows] == ["商用遮阳棚"]


def test_candidate_query_filters_status_and_risk(tmp_path):
    db_path = tmp_path / "test.db"
    init_database(db_path)
    upsert_candidate(
        {
            "product_name": "商用烧烤炉",
            "keyword": "烧烤炉",
            "title": "商用烧烤炉",
            "price": 500,
            "want_count": 30,
            "item_url": "https://www.goofish.com/item?id=200",
            "reason": "命中加权词",
            "risk_level": "低",
            "recommendation_status": "可交付候选",
        },
        db_path,
    )

    rows = query_candidates(
        db_path,
        keywords=["烧烤炉"],
        statuses=["可交付候选"],
        risk_levels=["低"],
    )

    assert len(rows) == 1
    assert rows[0]["title"] == "商用烧烤炉"

