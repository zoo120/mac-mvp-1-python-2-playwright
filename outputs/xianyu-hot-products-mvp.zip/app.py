"""Streamlit dashboard for the local Xianyu monitoring MVP."""

from __future__ import annotations

import sqlite3
from collections.abc import Sequence
from pathlib import Path
from typing import Any

from database import (
    DEFAULT_DB_PATH,
    get_connection,
    init_database,
    set_keyword_enabled,
)


PAGE_NAMES = ("今日概览", "关键词管理", "采集结果", "候选品")


def _placeholders(values: Sequence[Any]) -> str:
    return ",".join("?" for _ in values)


def get_dashboard_summary(
    db_path: str | Path = DEFAULT_DB_PATH,
) -> dict[str, int]:
    with get_connection(db_path) as connection:
        today_items = connection.execute(
            "SELECT COUNT(*) FROM crawled_items WHERE crawl_date = date('now', 'localtime')"
        ).fetchone()[0]
        enabled_keywords = connection.execute(
            "SELECT COUNT(*) FROM keywords WHERE enabled = 1"
        ).fetchone()[0]
        today_candidates = connection.execute(
            """
            SELECT COUNT(*) FROM product_candidates
            WHERE date(created_at, 'localtime') = date('now', 'localtime')
            """
        ).fetchone()[0]
    return {
        "today_items": int(today_items),
        "enabled_keywords": int(enabled_keywords),
        "today_candidates": int(today_candidates),
    }


def query_crawled_items(
    db_path: str | Path = DEFAULT_DB_PATH,
    *,
    keywords: Sequence[str] | None = None,
    min_price: float | None = None,
    max_price: float | None = None,
    min_want_count: int | None = None,
    limit: int = 1_000,
) -> list[sqlite3.Row]:
    conditions: list[str] = []
    params: list[Any] = []
    if keywords:
        conditions.append(f"keyword IN ({_placeholders(keywords)})")
        params.extend(keywords)
    if min_price is not None:
        conditions.append("price IS NOT NULL AND price >= ?")
        params.append(min_price)
    if max_price is not None:
        conditions.append("price IS NOT NULL AND price <= ?")
        params.append(max_price)
    if min_want_count is not None:
        conditions.append("want_count IS NOT NULL AND want_count >= ?")
        params.append(min_want_count)

    where_sql = f"WHERE {' AND '.join(conditions)}" if conditions else ""
    params.append(max(1, int(limit)))
    with get_connection(db_path) as connection:
        return connection.execute(
            f"""
            SELECT id, keyword, title, price, want_count, location, seller_type,
                   item_url, image_url, crawl_date, created_at
            FROM crawled_items
            {where_sql}
            ORDER BY crawl_date DESC, created_at DESC, id DESC
            LIMIT ?
            """,
            params,
        ).fetchall()


def query_candidates(
    db_path: str | Path = DEFAULT_DB_PATH,
    *,
    keywords: Sequence[str] | None = None,
    statuses: Sequence[str] | None = None,
    risk_levels: Sequence[str] | None = None,
    limit: int = 1_000,
) -> list[sqlite3.Row]:
    conditions: list[str] = []
    params: list[Any] = []
    for column, values in (
        ("keyword", keywords),
        ("recommendation_status", statuses),
        ("risk_level", risk_levels),
    ):
        if values:
            conditions.append(f"{column} IN ({_placeholders(values)})")
            params.extend(values)
    where_sql = f"WHERE {' AND '.join(conditions)}" if conditions else ""
    params.append(max(1, int(limit)))
    with get_connection(db_path) as connection:
        return connection.execute(
            f"""
            SELECT id, product_name, keyword, title, price, want_count, item_url,
                   reason, risk_level, recommendation_status, created_at
            FROM product_candidates
            {where_sql}
            ORDER BY
                CASE recommendation_status
                    WHEN '可交付候选' THEN 1
                    WHEN '可观察' THEN 2
                    ELSE 3
                END,
                created_at DESC,
                id DESC
            LIMIT ?
            """,
            params,
        ).fetchall()


def _rows_to_dataframe(rows: Sequence[sqlite3.Row], pandas_module: Any) -> Any:
    return pandas_module.DataFrame([dict(row) for row in rows])


def _keyword_options(db_path: str | Path = DEFAULT_DB_PATH) -> list[str]:
    with get_connection(db_path) as connection:
        return [
            str(row[0])
            for row in connection.execute(
                "SELECT keyword FROM keywords ORDER BY priority DESC, id ASC"
            ).fetchall()
        ]


def _render_overview(st: Any, pd: Any) -> None:
    st.header("今日概览")
    summary = get_dashboard_summary()
    columns = st.columns(3)
    columns[0].metric("今日采集数量", summary["today_items"])
    columns[1].metric("启用关键词", summary["enabled_keywords"])
    columns[2].metric("今日候选品", summary["today_candidates"])

    st.subheader("最近采集")
    recent = _rows_to_dataframe(query_crawled_items(limit=10), pd)
    if recent.empty:
        st.info("还没有采集数据。先在终端运行 `python crawler.py --keyword 遮阳棚 --limit 3`。")
        return
    st.dataframe(
        recent,
        width="stretch",
        hide_index=True,
        column_config={
            "item_url": st.column_config.LinkColumn("商品链接", display_text="打开商品"),
            "image_url": st.column_config.ImageColumn("图片"),
        },
    )


def _render_keywords(st: Any, pd: Any) -> None:
    st.header("关键词管理")
    st.caption("第一版支持启用或停用；优先级和备注可直接在 SQLite 中调整。")
    with get_connection() as connection:
        rows = connection.execute(
            """
            SELECT id, keyword, category, enabled, priority, note, updated_at
            FROM keywords ORDER BY priority DESC, id ASC
            """
        ).fetchall()
    original = _rows_to_dataframe(rows, pd)
    original["enabled"] = original["enabled"].astype(bool)
    edited = st.data_editor(
        original,
        width="stretch",
        hide_index=True,
        disabled=["id", "keyword", "category", "priority", "note", "updated_at"],
        column_config={
            "id": None,
            "keyword": "关键词",
            "category": "分类",
            "enabled": st.column_config.CheckboxColumn("启用"),
            "priority": "优先级",
            "note": "备注",
            "updated_at": "更新时间",
        },
        key="keyword_editor",
    )
    if st.button("保存启停设置", type="primary"):
        changed = 0
        original_state = dict(zip(original["id"], original["enabled"], strict=True))
        for row in edited.to_dict("records"):
            keyword_id = int(row["id"])
            enabled = bool(row["enabled"])
            if enabled != bool(original_state[keyword_id]):
                set_keyword_enabled(keyword_id, enabled)
                changed += 1
        if changed:
            st.success(f"已保存 {changed} 个关键词的启停状态。")
            st.rerun()
        else:
            st.info("没有需要保存的变化。")


def _render_results(st: Any, pd: Any) -> None:
    st.header("采集结果")
    keyword_options = _keyword_options()
    selected_keywords = st.multiselect("关键词", keyword_options)

    price_enabled = st.checkbox("启用价格筛选")
    min_price: float | None = None
    max_price: float | None = None
    if price_enabled:
        price_columns = st.columns(2)
        min_price = float(
            price_columns[0].number_input("最低价格", min_value=0.0, value=0.0, step=10.0)
        )
        max_price = float(
            price_columns[1].number_input(
                "最高价格", min_value=0.0, value=10_000.0, step=100.0
            )
        )

    wants_enabled = st.checkbox("启用最低想要数筛选")
    min_wants = (
        int(st.number_input("最低想要数", min_value=0, value=0, step=1))
        if wants_enabled
        else None
    )
    rows = query_crawled_items(
        keywords=selected_keywords,
        min_price=min_price,
        max_price=max_price,
        min_want_count=min_wants,
    )
    data = _rows_to_dataframe(rows, pd)
    st.caption(f"共 {len(data)} 条（最多显示 1000 条）")
    if data.empty:
        st.info("当前筛选条件下没有数据。")
        return
    st.dataframe(
        data,
        width="stretch",
        hide_index=True,
        column_config={
            "item_url": st.column_config.LinkColumn("商品链接", display_text="打开商品"),
            "image_url": st.column_config.ImageColumn("图片"),
            "price": st.column_config.NumberColumn("价格", format="¥ %.2f"),
            "want_count": st.column_config.NumberColumn("想要数", format="%d"),
        },
    )


def _render_candidates(st: Any, pd: Any) -> None:
    st.header("候选品")
    st.caption("表格文字可选中后按 ⌘C 复制；商品链接可直接点击。")
    filter_columns = st.columns(3)
    selected_keywords = filter_columns[0].multiselect("关键词", _keyword_options())
    selected_statuses = filter_columns[1].multiselect(
        "推荐状态", ["可交付候选", "可观察", "不建议"]
    )
    selected_risks = filter_columns[2].multiselect("风险等级", ["低", "中", "高"])
    rows = query_candidates(
        keywords=selected_keywords,
        statuses=selected_statuses,
        risk_levels=selected_risks,
    )
    data = _rows_to_dataframe(rows, pd)
    st.caption(f"共 {len(data)} 条（最多显示 1000 条）")
    if data.empty:
        st.info("当前筛选条件下没有候选品。")
        return
    st.dataframe(
        data,
        width="stretch",
        hide_index=True,
        column_config={
            "item_url": st.column_config.LinkColumn("商品链接", display_text="打开商品"),
            "price": st.column_config.NumberColumn("价格", format="¥ %.2f"),
            "want_count": st.column_config.NumberColumn("想要数", format="%d"),
        },
    )


def main() -> None:
    try:
        import pandas as pd
        import streamlit as st
    except ImportError as exc:
        raise RuntimeError(
            "后台依赖尚未安装，请先运行 pip install -r requirements.txt"
        ) from exc

    st.set_page_config(page_title="闲鱼热卖品监测", page_icon="📦", layout="wide")
    init_database()
    st.title("闲鱼热卖品监测 MVP")
    page = st.sidebar.radio("页面", PAGE_NAMES)
    st.sidebar.caption("本地 SQLite · 顺序低频采集")

    if page == "今日概览":
        _render_overview(st, pd)
    elif page == "关键词管理":
        _render_keywords(st, pd)
    elif page == "采集结果":
        _render_results(st, pd)
    else:
        _render_candidates(st, pd)


if __name__ == "__main__":
    main()
